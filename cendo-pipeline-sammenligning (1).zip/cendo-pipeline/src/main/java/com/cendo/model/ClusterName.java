package com.cendo.model;

/** A short human-readable name and one-sentence description for a cluster. */
public record ClusterName(String name, String description) {
}
