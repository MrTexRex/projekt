package com.cendo.llm;

import com.cendo.http.JsonHttpClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;

/**
 * Adapter for a local Ollama server (free, runs on your own computer).
 * Uses Ollama's native /api/chat endpoint because it lets us set two important options:
 *  - format=json: forces the model to answer with valid JSON (small models often forget otherwise)
 *  - num_ctx: the context window. Ollama's default is small and silently cuts off long prompts.
 */
public class OllamaChatClient implements ChatClient {

    private static final int CONTEXT_TOKENS = 8192;

    private final JsonHttpClient http;
    private final String url;
    private final String model;

    public OllamaChatClient(JsonHttpClient http, String baseUrl, String model) {
        this.http = http;
        this.url = baseUrl.replaceAll("/+$", "") + "/api/chat";
        this.model = model;
    }

    @Override
    public String model() {
        return model;
    }

    @Override
    public String complete(String systemPrompt, String userMessage) throws IOException, InterruptedException {
        ObjectNode body = http.mapper().createObjectNode();
        body.put("model", model);
        body.put("stream", false);
        body.put("format", "json");
        ObjectNode options = body.putObject("options");
        options.put("temperature", 0.1);
        options.put("num_ctx", CONTEXT_TOKENS);
        ArrayNode messages = body.putArray("messages");
        messages.addObject().put("role", "system").put("content", systemPrompt);
        messages.addObject().put("role", "user").put("content", userMessage);

        JsonNode response = http.postJson(url, body);
        String content = response.path("message").path("content").asText("");
        return LlmText.removeThinking(content).strip();
    }
}
