package com.cendo.naming;

import com.cendo.model.ClusterName;

import java.io.IOException;
import java.util.List;

/** Pipeline step 6: gives a cluster a human-readable name based on examples from it. */
public interface ClusterNamer {

    ClusterName name(List<String> examples) throws IOException, InterruptedException;
}
