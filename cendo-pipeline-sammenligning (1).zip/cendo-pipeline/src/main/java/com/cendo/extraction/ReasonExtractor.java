package com.cendo.extraction;

import com.cendo.model.TransferReason;

import java.io.IOException;

/** Pipeline step 2: turns a whole transcript into a short primary reason plus an explanatory sentence. */
public interface ReasonExtractor {

    TransferReason extractReason(String transcript) throws IOException, InterruptedException;
}
